/**
 * @license Highcharts Gantt JS v7.1.3 (2019-08-14)
 * @module highcharts/modules/current-date-indicator
 * @requires highcharts
 *
 * CurrentDateIndicator
 *
 * (c) 2010-2019 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/CurrentDateIndicator.js';
