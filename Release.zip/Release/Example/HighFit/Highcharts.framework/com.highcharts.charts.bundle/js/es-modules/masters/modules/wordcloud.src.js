/**
 * @license Highcharts JS v7.1.3 (2019-08-14)
 * @module highcharts/modules/wordcloud
 * @requires highcharts
 *
 * (c) 2016-2019 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/wordcloud.src.js';
