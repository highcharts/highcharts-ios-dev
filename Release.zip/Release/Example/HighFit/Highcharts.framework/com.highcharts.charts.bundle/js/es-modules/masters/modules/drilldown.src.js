/**
 * @license Highcharts JS v7.1.3 (2019-08-14)
 * @module highcharts/modules/drilldown
 * @requires highcharts
 *
 * Highcharts Drilldown module
 *
 * Author: Torstein Honsi
 * License: www.highcharts.com/license
 *
 */
'use strict';
import '../../modules/drilldown.src.js';
