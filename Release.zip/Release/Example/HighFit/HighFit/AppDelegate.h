//
//  AppDelegate.h
//  HighFit
//
//  License: www.highcharts.com/license
//  Copyright © 2021 Highsoft AS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

