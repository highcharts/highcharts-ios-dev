//
//  ListDataTableViewController.h
//  HighFit
//
//  License: www.highcharts.com/license
//  Copyright © 2018 Highsoft AS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListDataTableViewController : UITableViewController

@end
