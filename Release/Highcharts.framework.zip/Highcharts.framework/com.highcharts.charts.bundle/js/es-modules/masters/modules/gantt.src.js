/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Gantt series
 *
 * (c) 2016-2018 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/GanttSeries.js';
import '../../parts-gantt/GanttChart.js';
