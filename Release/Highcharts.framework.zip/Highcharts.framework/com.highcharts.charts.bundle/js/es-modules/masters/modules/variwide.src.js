/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * Highcharts variwide module
 *
 * (c) 2010-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/variwide.src.js';
