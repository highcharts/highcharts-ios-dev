/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Data grouping module
 *
 * (c) 2010-2019 Torstein Hønsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import dataGrouping from '../../parts/DataGrouping.js';
export default dataGrouping;
