/**
 * @license Highcharts JS v8.0.0 (2019-12-10)
 * @module highcharts/themes/sunset
 * @requires highcharts
 *
 * (c) 2009-2019 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/sunset.js';
